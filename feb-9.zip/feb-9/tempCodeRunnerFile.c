
    // Print the sum of unique digits